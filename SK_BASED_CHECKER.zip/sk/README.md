# SK-CHECKER
![PHP](https://img.shields.io/badge/language-PHP-blue.svg)
![BANDITCODING](https://img.shields.io/badge/Team-Banditcoding-green)
![AUTHOR](https://img.shields.io/badge/Author-Zlaxtert-orange)

## Install on localhost : 
- Install XAMPP
- Clone Repositories
- Extract files in .htdocs folder
- then start XAMPP
- And run on localhost
- go to https://localhost/sk-checker/
