<?php

echo '<div class="live_cvv" style="display: none;"><span class="badge badge-primary">CVV LIVE</span> <span style="color: #FFFFFF"> Tikol4Life Test Mode</span></div>';
?>
