<?php

echo '<div class="live_ccn" style="display:none;"><span class="badge badge-warning">CCN LIVE</span> <span style="color: #FFFFFF"> Tikol4Life Test Mode</span></div>';
?>
